//Sam Dressler
struct _data* LOAD (FILE *stream, int size);

