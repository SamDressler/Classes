//Sam Dressler
void SEARCH (struct _data *BlackBox, char *name, int size);
