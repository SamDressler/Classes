//Sam Dressler
void FREE (struct _data *BlackBox, int size);

