//Sam Dressler
int SCAN (FILE *(*stream));


