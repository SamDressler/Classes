//Sam Dressler
#include <stdio.h>
#include <stdlib.h>
struct _data* LOAD (FILE *stream, int size);

