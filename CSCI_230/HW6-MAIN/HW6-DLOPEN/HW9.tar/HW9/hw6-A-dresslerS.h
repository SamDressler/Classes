//Sam Dressler
#include <stdio.h>
#include <stdlib.h>
int SCAN (FILE *(*stream));


